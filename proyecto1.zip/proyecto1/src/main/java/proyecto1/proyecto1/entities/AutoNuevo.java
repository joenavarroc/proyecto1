package proyecto1.proyecto1.entities;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class AutoNuevo extends Vehiculo {
    
    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, int potencia) {
        super(marca, modelo, color, marcaRadio, potencia);
    }

    @Override
    public String toString() {
        return super.toString()+"AutoNuevo []";
    }  
}
