package proyecto1.proyecto1.entities;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class Radio {
    String marcaRadio;
    int potencia;
    public Radio(String marcaRadio, int potencia) {
        this.marcaRadio = marcaRadio;
        this.potencia = potencia;
    }
    public String getMarca() {
        return marcaRadio;
    }
    public int getPotencia() {
        return potencia;
    } 
}
