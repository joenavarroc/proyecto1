package proyecto1.proyecto1.entities;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class AutoClasico extends Vehiculo {
    
    
    public AutoClasico(String marca, String modelo, String color, double precio, String marcaRadio, int potencia) {
        super(marca, modelo, color, precio,marcaRadio,potencia);
        
    }
    public AutoClasico(String marca, String modelo, String color, String marcaRadio, int potencia) {
        super(marca, modelo, color, marcaRadio, potencia);
        
    }
    public AutoClasico(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
    }
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }
    @Override
    public String toString() {
        return super.toString()+ "AutoClasico []";
    }
    
}
