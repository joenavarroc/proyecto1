package proyecto1.proyecto1;

import proyecto1.proyecto1.entities.AutoClasico;
import proyecto1.proyecto1.entities.AutoNuevo;
import proyecto1.proyecto1.entities.Bondis;
import proyecto1.proyecto1.entities.Radio;

public class TestVehiculo {
    public static void main(String[] args) {
        
        System.out.println("autoclasico");
        AutoClasico autoClasico=new AutoClasico("Renault", "Megane", "Azul");
        System.out.println(autoClasico);

        System.out.println("autoclasico");
        AutoClasico autoClasico2=new AutoClasico("Renault", "12", "Verde", 584000);
        System.out.println(autoClasico2);

        System.out.println("autoclasico");
        AutoClasico autoClasico3=new AutoClasico("Renault", "Clio", "Blanco", "Sony", 4364);
        System.out.println(autoClasico3);

        System.out.println("autoclasico");
        AutoClasico autoClasico4=new AutoClasico("Renault", "Sandero", "Marron", 954200, "Panasonic", 69700);
        System.out.println(autoClasico4);

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");

        System.out.println("autonuevo");
        AutoNuevo autoNuevo=new AutoNuevo("Ford", "Mustang", "negro", "JBL", 5699);
        System.out.println(autoNuevo);

        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");

        System.out.println("bondis");
        Bondis bondis=new Bondis("Scania", "V8", "Plateado");
        System.out.println(bondis);

        System.out.println("bondis");
        Bondis bondis2=new Bondis("Volvo", "9700", "Gris", 10000);
        System.out.println(bondis2);

        System.out.println("bondis");
        Bondis bondis3=new Bondis("Mercedes Benz", "Marcopolo", "blanco", "Pioneer", 500);
        System.out.println(bondis3);

        System.out.println("bondis");
        Bondis bondis4=new Bondis("Chevrolet", "B60", "Amarillo", 1398700, "Philips", 20000);
        System.out.println(bondis4);
    }
}
