package proyecto1.proyecto1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
